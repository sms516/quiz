<?php

namespace Illuminate\Container;

use Exception;

/**
 * @deprecated since version 5.1. Use Illuminate\Contracts\Container\BindingResolutionException.
 */
class BindingResolutionException extends Exception
{
}
