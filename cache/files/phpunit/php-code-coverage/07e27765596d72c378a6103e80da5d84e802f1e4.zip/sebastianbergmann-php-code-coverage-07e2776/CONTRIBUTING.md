Pull Requests for bug fixes should be made against the current release branch (2.0).

Pull Requests for new features should be made against master.

For further notes please refer to [https://github.com/sebastianbergmann/phpunit/blob/master/CONTRIBUTING.md](https://github.com/sebastianbergmann/phpunit/blob/master/CONTRIBUTING.md)
